import React, {Component} from 'react';
import {SafeAreaView} from 'react-native';

class SecondTabItem extends Component {
  render() {
    return (
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: 'blue',
        }}></SafeAreaView>
    );
  }
}
export default SecondTabItem;
