import React, {Component} from 'react';
import {View, Text, SafeAreaView, Image} from 'react-native';
import Icon from 'react-native-vector-icons';
import {VectorIcon} from '../assets/vectoreicon';
import {string} from 'prop-types';
import {Button} from 'react-native-elements';

export class NavHeader extends Component {
  static navigationOptions = ({navigation}) => {
    // console.log(navigation.getParam());
    const backBtn = () => {
      const backProps = navigation.getParam('backProps');
      if (typeof backProps === 'undefined') {
        return null;
      }
      const containerStyle = backProps?.containerStyle;
      const buttonStyle = backProps?.buttonStyle;
      const onPress = backProps?.onPress;
      return (
        <Button
          title="Back"
          onPress={onPress}
          containerStyle={[containerStyle]}
          buttonStyle={[
            {
              width: '100%',
              height: '100%',
              backgroundColor: 'gray',
            },
            buttonStyle,
          ]}
          titleStyle={{
            color: 'black',
          }}
        />
      );
    };

    const imgBtn = () => {
      const imgProps = navigation.getParam('imgProps');
      const source = imgProps?.source;
      return (
        <Image
          source={`${source}`}
          style={{width: 30, height: 30, borderRadius: 100}}
        />
      );
    };

    const headerBackground = () => {
      const headerBackProps = navigation.getParam('headerBackProps');
      const color = headerBackProps?.color;
      return (
        <View
          style={{
            width: '100%',
            height: '100%',
            backgroundColor: color ? color : 'lightgray',
          }}></View>
      );
    };
    return {
      // headerShow:
      title: navigation.getParam('title'),
      headerBackground: headerBackground(),
      headerLeft: [imgBtn(), backBtn()],
      headerLeftContainerStyle: {
        flexDirection: 'row',
        marginLeft: '1%',
        alignItems: 'center',
      },
      headerRight: [],
      headerRightContainerStyle: {
        flexDirection: 'row',
        marginRight: '1%',
        alignItems: 'center',
      },
    };
  };
}

export default NavHeader;

// //<SafeAreaView>
// <View
// style={{
//   display: 'flex',
//   flexDirection: 'row',
//   justifyContent: 'space-between',
//   alignItems: 'center',
//   paddingHorizontal: 10,
// }}>
// <View
//   style={{
//     display: 'flex',
//     flexDirection: 'row',
//     justifyContent: 'center',
//     alignItems: 'center',
//   }}>
//   <Image
//     source={require('../assets/image.jpeg')}
//     style={{width: 50, height: 50, borderRadius: 100, marginEnd: 5}}
//   />
//   <View>
//     <Text style={{fontSize: 18}}>Start a new project</Text>
//     <Text style={{fontSize: 12}}>view more details</Text>
//   </View>
// </View>
// <View
//   style={{
//     display: 'flex',
//     flexDirection: 'row',
//     justifyContent: 'center',
//     alignItems: 'center',
//   }}>
//   {/* <Icon size={20} name="notifications-outline" color={'lightgray'} /> */}
//   <VectorIcon
//     size={20}
//     type="Ionicons"
//     name="notifications-outline"
//     color={'#000'}
//     style={{marginEnd: 10}}
//   />
//   <VectorIcon
//     size={20}
//     type="Ionicons"
//     name="menu-outline"
//     color={'#000'}
//     style={{}}
//   />
// </View>
// </View>
// </SafeAreaView>

// classfunction Header() {
//   return (
//     <SafeAreaView>
//       <View
//         style={{
//           display: 'flex',
//           flexDirection: 'row',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           paddingHorizontal: 10,
//         }}>
//         <View
//           style={{
//             display: 'flex',
//             flexDirection: 'row',
//             justifyContent: 'center',
//             alignItems: 'center',
//           }}>
//           <Image
//             source={require('../assets/image.jpeg')}
//             style={{width: 50, height: 50, borderRadius: 100, marginEnd: 5}}
//           />
//           <View>
//             <Text style={{fontSize: 18}}>Start a new project</Text>
//             <Text style={{fontSize: 12}}>view more details</Text>
//           </View>
//         </View>
//         <View
//           style={{
//             display: 'flex',
//             flexDirection: 'row',
//             justifyContent: 'center',
//             alignItems: 'center',
//           }}>
//           {/* <Icon size={20} name="notifications-outline" color={'lightgray'} /> */}
//           <VectorIcon
//             size={20}
//             type="Ionicons"
//             name="notifications-outline"
//             color={'#000'}
//             style={{marginEnd: 10}}
//           />
//           <VectorIcon
//             size={20}
//             type="Ionicons"
//             name="menu-outline"
//             color={'#000'}
//             style={{}}
//           />
//         </View>
//       </View>
//     </SafeAreaView>
//   );
// }
