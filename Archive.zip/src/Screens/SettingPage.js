import React, {Component} from 'react';
import {SafeAreaView} from 'react-native';

class SettingPage extends Component {
  render() {
    return (
      <SafeAreaView
        style={{
          flex: 1,
          backgroundColor: 'yellow',
        }}></SafeAreaView>
    );
  }
}
export default SettingPage;
