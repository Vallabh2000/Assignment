import * as React from 'react';
import {Button as IconButton} from '@rneui/themed';
import inputStyles from './Components/CustomInput';
// import Ionicons from 'react-native-vector-icons/Ionicons';
// import Navigationscreen from './src/navigation/index';
import Navigationscreen from './src/navigation';

// import {
//   Button,
//   SafeAreaView,
//   ScrollView,
//   StatusBar,
//   StyleSheet,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   TouchableOpacityComponent,
//   useColorScheme,
//   View,
// } from 'react-native';
// import HomeScreen from './Screens/HomeScreen';
// import Login from './Screens/Login';
// import SignUp from './Screens/SignUp';

// import {createStackNavigator} from 'react-navigation-stack';
// import {createAppContainer, createSwitchNavigator} from 'react-navigation';
// import {createBottomTabNavigator} from 'react-navigation-tabs';
// import DetailsScreen from './Screens/DetailScreen';
// import SettingsScreen from './Screens/Setting';
// import {createDrawerNavigator} from 'react-navigation-drawer';

// class Screen1 extends React.Component {
//   //Screen1 Component
//   render() {
//     return (
//       <View style={styles.MainContainer}>
//         <Text style={{fontSize: 23}}> Screen 1 </Text>
//       </View>
//     );
//   }
// }
// class Screen2 extends React.Component {
//   //Screen1 Component
//   render() {
//     return (
//       <View style={styles.MainContainer}>
//         <Text style={{fontSize: 23}}> Screen 1 </Text>
//       </View>
//     );
//   }
// }
// class Screen3 extends React.Component {
//   //Screen1 Component
//   render() {
//     return (
//       <View style={styles.MainContainer}>
//         <Text style={{fontSize: 23}}> Screen 1 </Text>
//       </View>
//     );
//   }
// }

// const styles = StyleSheet.create({
//   MainContainer: {
//     flex: 1,
//     paddingTop: 20,
//     alignItems: 'center',
//     marginTop: 50,
//     justifyContent: 'center',
//   },
// });

// class NavigationDrawerStructure extends React.Component {
//   //Structure for the navigatin Drawer
//   toggleDrawer = () => {
//     //Props to open/close the drawer
//     this.props.navigationProps.toggleDrawer();
//   };
//   render() {
//     return (
//       <View style={{flexDirection: 'row'}}>
//         <TouchableOpacity onPress={this.toggleDrawer.bind(this)}>
//           {/*Donute Button Image */}
//           <Text>Drawer</Text>
//         </TouchableOpacity>
//       </View>
//     );
//   }
// }

// const FirstActivity_StackNavigator = createStackNavigator({
//   //All the screen from the Screen1 will be indexed here
//   First: {
//     screen: Screen1,
//     navigationOptions: ({navigation}) => ({
//       title: 'Demo Screen 1',
//       headerLeft: () => (
//         <NavigationDrawerStructure navigationProps={navigation} />
//       ),
//       headerStyle: {
//         backgroundColor: '#FF9800',
//       },
//       headerTintColor: '#fff',
//     }),
//   },
// });

// const Screen2_StackNavigator = createStackNavigator({
//   //All the screen from the Screen2 will be indexed here
//   Second: {
//     screen: Screen2,
//     navigationOptions: ({navigation}) => ({
//       title: 'Demo Screen 2',
//       headerLeft: () => (
//         <NavigationDrawerStructure navigationProps={navigation} />
//       ),
//       headerStyle: {
//         backgroundColor: '#FF9800',
//       },
//       headerTintColor: '#fff',
//     }),
//   },
// });

// const Screen3_StackNavigator = createStackNavigator({
//   //All the screen from the Screen3 will be indexed here
//   Third: {
//     screen: Screen3,
//     navigationOptions: ({navigation}) => ({
//       title: 'Demo Screen 3',
//       headerLeft: () => (
//         <NavigationDrawerStructure navigationProps={navigation} />
//       ),
//       headerStyle: {
//         backgroundColor: '#FF9800',
//       },
//       headerTintColor: '#fff',
//     }),
//   },
// });

// const DrawerNavigatorExample = createDrawerNavigator(
//   {
//     Stack,
//   },
//   {
//     contentComponent: props => {
//       return;
//       <View>
//         <Text>Home</Text>
//         <Text>Login</Text>
//         <Text>SignUp</Text>
//       </View>;
//     },
//   },
// );

// const Stack = createStackNavigator(
//   {
//     HomeScreen: {screen: HomeScreen},
//     Login: {screen: Login},
//     SignUp: {screen: SignUp},
//   },
//   {
//     initialRouteName: 'Login',
//   },
// );

// const AppStack = createStackNavigator(
//   {
//     Detail: {screen: DetailsScreen},
//     Setting: {screen: SettingsScreen},
//   },
//   {
//     initialRouteName: 'Detail',
//   },
// );

// const Main = createAppContainer(
//   createBottomTabNavigator(
//     {
//       Home: {screen: DrawerNavigatorExample},
//       Profile: {screen: AppStack},
//     },
//     {initialRouteName: 'Home'},
//   ),
// );

// const Main = createAppContainer(MyDrawerNavigator);

// class App extends React.Component {
//   render() {
//     return <Main />;
//   }
// }

// const Main = createAppContainer(DrawerNavigatorExample);

class App extends React.Component {
  render() {
    return <Navigationscreen />;
  }
}

export default App;
